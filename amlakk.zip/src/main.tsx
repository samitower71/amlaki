import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Register PWA Service Worker & Clear old cache to prevent white-screen issues
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    // Clean old caches
    if ('caches' in window) {
      caches.keys().then((names) => {
        for (const name of names) {
          caches.delete(name);
        }
      }).catch(err => console.log('Cache clear failed:', err));
    }

    // Register fresh service worker
    navigator.serviceWorker.register('/sw.js')
      .then(reg => {
        console.log('Service Worker registered successfully:', reg.scope);
        // Ensure the service worker updates immediately
        reg.update().catch(() => {});
      })
      .catch(err => console.log('Service Worker registration failed:', err));
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

