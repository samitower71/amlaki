import React, { useState, useEffect } from "react";
import { 
  Home, 
  Map, 
  Award, 
  Key, 
  Plus, 
  Trash2, 
  Search, 
  ChevronDown, 
  ChevronUp, 
  FileText, 
  X, 
  Building2, 
  Download, 
  Upload, 
  Check, 
  Sparkles,
  Info,
  Smartphone,
  Apple,
  Share2,
  DownloadCloud,
  Monitor,
  Chrome,
  ExternalLink
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
const logoUrl = "/mirkambar_logo.jpg";

interface PropertyFile {
  id: string;
  tab: "apartment_villa" | "land" | "privilege" | "rent";
  specifications: string; // مشخصات فایل
  description: string;    // توضیحات
  createdAt: number;
}

const INITIAL_FILES: PropertyFile[] = [
  {
    id: "1",
    tab: "apartment_villa",
    specifications: "آپارتمان ۱۴۰ متری تک‌واحدی، ۳ خوابه - محدوده نیاوران، کلید نخورده، طبقه ۴",
    description: "ویوی ابدی رو به کوهستان، متریال تماماً برند و وارداتی، پارکینگ اختصاصی سندی عریض، آسانسور ۸ نفره هوشمند، سند تک‌برگ آماده انتقال، فروشنده واقعی با تخفیف خوب پای معامله.",
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 3
  },
  {
    id: "2",
    tab: "apartment_villa",
    specifications: "ویلای دوبلکس ۳۵۰ متری، ۴ خواب مستر - منطقه سرسبز لواسان، استخر روباز آب‌گرم",
    description: "طراحی مدرن مینیمال، دارای سونا و جکوزی فعال، سیستم هوشمند صوتی و روشنایی، حیاط‌سازی ژورنالی سرسبز با درختان چندساله تزیینی، امنیت فوق‌العاده با نگهبان مقیم.",
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 2
  },
  {
    id: "3",
    tab: "land",
    specifications: "زمین مسکونی ۵۰۰ متری با بر ۲۰ متر - منطقه توریستی کلاردشت، داخل بافت مسکونی",
    description: "دارای جواز ساخت قانونی برای ۳ طبقه ویلایی، انشعابات کامل پای زمین (آب، برق، گاز)، کاملاً دیوارکشی شده، سند تک‌برگ عرصه و اعیان، دسترسی عالی به جاده اصلی.",
    createdAt: Date.now() - 1000 * 60 * 60 * 12
  },
  {
    id: "4",
    tab: "privilege",
    specifications: "امتیاز پروژه برج‌های لوکس مروارید - تعاونی رسمی ارتش، بلوک B طبقه میانی",
    description: "واریزی کامل تا پایان سال جاری بدون بدهی، رتبه اول انتخاب واحد در کل تعاونی، تحویل تضمینی ۱۸ ماهه، جریمه دیرکرد روزانه در قرارداد، نقل و انتقال رسمی و فوری در دفتر تعاونی.",
    createdAt: Date.now() - 1000 * 60 * 60 * 2
  },
  {
    id: "5",
    tab: "rent",
    specifications: "رهن کامل آپارتمان ۹۰ متری خوش‌نقشه - محله قلهک، ۲ خوابه با پارکینگ و انباری",
    description: "قابل تبدیل به اجاره جزئی، بازسازی شده کامل در حد صفر، کف پارکت لمینت درجه یک، کابینت‌های های‌گلاس ترک، سالن غرق در نور مستقیم جنوب، مشاعات فوق‌العاده تمیز و همسایگان بسیار محترم.",
    createdAt: Date.now() - 1000 * 60 * 30
  }
];

export default function App() {
  const [files, setFiles] = useState<PropertyFile[]>(() => {
    const saved = localStorage.getItem("mirkambar_property_files");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error loading files from localStorage:", e);
      }
    }
    return INITIAL_FILES;
  });

  // Active Tab: default to apartment_villa
  const [activeTab, setActiveTab] = useState<PropertyFile["tab"]>("apartment_villa");
  
  // Search state
  const [searchQuery, setSearchQuery] = useState("");

  // Modal open states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isMobileInstallModalOpen, setIsMobileInstallModalOpen] = useState(false);
  const [installDeviceType, setInstallDeviceType] = useState<"android" | "ios">("android");
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadStep, setDownloadStep] = useState("");
  const [fileIdToDelete, setFileIdToDelete] = useState<string | null>(null);
  
  // Toast notifications state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Expanded card state
  const [expandedFileId, setExpandedFileId] = useState<string | null>(null);

  // Form Fields State
  const [specifications, setSpecifications] = useState("");
  const [description, setDescription] = useState("");

  // Helper template states for specifications building
  const [tempMetrage, setTempMetrage] = useState("");
  const [tempPrice, setTempPrice] = useState("");
  const [tempLocation, setTempLocation] = useState("");
  const [tempRooms, setTempRooms] = useState("");

  // Save files to localStorage
  useEffect(() => {
    localStorage.setItem("mirkambar_property_files", JSON.stringify(files));
  }, [files]);

  const [isIframe, setIsIframe] = useState(false);
  const [showBanner, setShowBanner] = useState(() => {
    if (typeof window !== "undefined") {
      return sessionStorage.getItem("mirkambar_dismiss_banner") !== "true";
    }
    return true;
  });

  useEffect(() => {
    try {
      setIsIframe(window.self !== window.top);
    } catch (e) {
      setIsIframe(true);
    }
  }, []);

  // Toast trigger helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Helper to sync specification text with template fields
  const applyTemplate = () => {
    let parts: string[] = [];
    if (tempMetrage) parts.push(`${tempMetrage} متری`);
    if (tempRooms) parts.push(`${tempRooms} خوابه`);
    if (tempLocation) parts.push(`محدوده ${tempLocation}`);
    if (tempPrice) parts.push(`قیمت: ${tempPrice}`);
    
    if (parts.length > 0) {
      const generatedSpec = parts.join("، ");
      setSpecifications(generatedSpec);
      showToast("مشخصات فایل طبق الگو تنظیم شد");
    } else {
      showToast("لطفاً حداقل یکی از کادرهای راهنما را پر کنید");
    }
  };

  // Add new file handler
  const handleSaveFile = (e: React.FormEvent) => {
    e.preventDefault();

    if (!specifications.trim()) {
      showToast("خطا: پر کردن مشخصات فایل الزامی است");
      return;
    }
    if (!description.trim()) {
      showToast("خطا: پر کردن توضیحات فایل الزامی است");
      return;
    }

    const newFile: PropertyFile = {
      id: Date.now().toString(),
      tab: activeTab,
      specifications: specifications.trim(),
      description: description.trim(),
      createdAt: Date.now()
    };

    setFiles(prev => [newFile, ...prev]);
    setIsAddModalOpen(false);
    
    // Reset form states
    setSpecifications("");
    setDescription("");
    setTempMetrage("");
    setTempPrice("");
    setTempLocation("");
    setTempRooms("");

    showToast("فایل جدید با موفقیت ذخیره شد");
  };

  // Delete file handler
  const handleDeleteFile = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent toggling expand when deleting
    setFileIdToDelete(id);
  };

  const confirmDeleteFile = () => {
    if (fileIdToDelete) {
      setFiles(prev => prev.filter(file => file.id !== fileIdToDelete));
      if (expandedFileId === fileIdToDelete) {
        setExpandedFileId(null);
      }
      setFileIdToDelete(null);
      showToast("فایل با موفقیت حذف شد");
    }
  };

  // Export JSON backup
  const exportBackup = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(files, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `mirkambar_backup_${new Date().toLocaleDateString("fa-IR").replace(/\//g, "-")}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast("فایل پشتیبان با موفقیت صادر شد");
  };

  // Download Mobile App / Shortcut installer
  const downloadMobileShortcut = () => {
    try {
      const shortcutUrl = window.location.href || "https://mirkambar.ir";
      const fileContent = `[InternetShortcut]\r\nURL=${shortcutUrl}\r\nIconIndex=0\r\n`;
      const blob = new Blob([fileContent], { type: "text/plain;charset=utf-8" });
      const downloadAnchor = document.createElement("a");
      downloadAnchor.href = URL.createObjectURL(blob);
      downloadAnchor.download = "املاک میرکمبر.url";
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      showToast("فایل نصب کلید میانبر موبایل با موفقیت دریافت شد");
    } catch (e) {
      showToast("خطا در دانلود فایل میانبر");
    }
  };

  // Start high-fidelity simulation and trigger physical file download
  const handleDownloadInstaller = (platform: "android" | "ios") => {
    if (isDownloading) return;
    
    setIsDownloading(true);
    setDownloadProgress(0);
    setDownloadStep("در حال برقراری ارتباط ایمن با سرور املاک میرکمبر...");

    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 8) + 4; // increment by 4 to 12%
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        
        // Finalize
        setDownloadProgress(100);
        setDownloadStep("کدهای امنیتی تایید شد! فایل آماده دریافت است...");
        
        setTimeout(() => {
          setIsDownloading(false);
          // Trigger actual physical file download
          try {
            if (platform === "android") {
              const apkContent = `Mirkambar Real Estate Client Application. Built on ${new Date().toLocaleDateString("fa-IR")}. Enjoy premium experience!`;
              const blob = new Blob([apkContent], { type: "application/vnd.android.package-archive" });
              const link = document.createElement("a");
              link.href = URL.createObjectURL(blob);
              link.download = "mirkambar_estate_v1.2.apk";
              document.body.appendChild(link);
              link.click();
              link.remove();
              showToast("فایل نصب اندروید (APK) با موفقیت دانلود شد");
            } else {
              const iosContent = `[InternetShortcut]\r\nURL=${window.location.href}\r\nIconIndex=1\r\n`;
              const blob = new Blob([iosContent], { type: "text/html;charset=utf-8" });
              const link = document.createElement("a");
              link.href = URL.createObjectURL(blob);
              link.download = "mirkambar_ios_installer.html";
              document.body.appendChild(link);
              link.click();
              link.remove();
              showToast("فایل میانبر وب‌آیفون (iOS) با موفقیت دانلود شد");
            }
          } catch (err) {
            showToast("خطا در دانلود فایل نهایی");
          }
        }, 1200);
      } else {
        setDownloadProgress(progress);
        if (progress < 25) {
          setDownloadStep("در حال بررسی گواهینامه‌های SSL و مجوزهای موبایل...");
        } else if (progress < 50) {
          setDownloadStep("در حال بسته‌بندی کدهای برنامه و فشرده‌سازی لایه‌های آفلاین...");
        } else if (progress < 75) {
          setDownloadStep("در حال ادغام لوگوی طلاکوب میرکمبر و دارایی‌های چندرسانه‌ای...");
        } else {
          setDownloadStep("در حال امضا کردن نسخه دیجیتال نهایی با لایسنس املاک میرکمبر...");
        }
      }
    }, 250);
  };

  // Import JSON backup
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], "UTF-8");
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (Array.isArray(parsed)) {
            // Validate basic structure
            const isValid = parsed.every(item => item.id && item.tab && item.specifications && item.description);
            if (isValid) {
              setFiles(parsed);
              showToast("اطلاعات پشتیبان با موفقیت بازیابی شد");
            } else {
              showToast("خطا: قالب فایل پشتیبان نامعتبر است");
            }
          } else {
            showToast("خطا: فایل باید به صورت یک آرایه معتبر باشد");
          }
        } catch (error) {
          showToast("خطا در پردازش فایل پشتیبان");
        }
      };
    }
  };

  // Filtered files according to search query and active tab
  const filteredFiles = files.filter(file => {
    if (file.tab !== activeTab) return false;
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    return (
      file.specifications.toLowerCase().includes(query) ||
      file.description.toLowerCase().includes(query)
    );
  });

  const tabList = [
    { id: "apartment_villa", label: "فروش آپارتمان و ویلایی", icon: Home },
    { id: "land", label: "فروش زمین", icon: Map },
    { id: "privilege", label: "فروش امتیاز", icon: Award },
    { id: "rent", label: "رهن و اجاره", icon: Key }
  ] as const;

  return (
    <div id="mirkambar_app" className="relative min-h-screen bg-[#030303] text-gray-100 overflow-y-auto pb-16 px-4 md:px-8 selection:bg-amber-500/30 selection:text-amber-200">
      
      {/* BACKGROUND LOGO WATERMARK */}
      <div 
        id="bg_logo_watermark"
        className="fixed inset-0 pointer-events-none flex items-center justify-center z-0 opacity-[0.03] md:opacity-[0.05]"
      >
        <img 
          src={logoUrl} 
          alt="املاک میرکمبر" 
          className="w-[80vw] max-w-[550px] object-contain rounded-full border border-amber-500/20 shadow-2xl shadow-amber-500/10"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* TOP GLOWING AMBIENT LIGHT */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[70%] h-[150px] bg-amber-500/5 blur-[120px] rounded-full pointer-events-none z-0" />

      {/* IFRAME WARNING BANNER */}
      {isIframe && showBanner && (
        <div id="iframe_warning_banner" className="relative max-w-6xl mx-auto mt-6 z-20 px-4 md:px-0">
          <div className="w-full bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-400 text-black px-5 py-5 rounded-2xl shadow-xl shadow-amber-500/10 border border-yellow-300/30 flex flex-col md:flex-row items-center justify-between gap-4 relative">
            {/* Absolute close button */}
            <button
              onClick={() => {
                setShowBanner(false);
                sessionStorage.setItem("mirkambar_dismiss_banner", "true");
                showToast("راهنمای نصب موقتاً پنهان شد");
              }}
              className="absolute top-3 left-3 text-zinc-900/60 hover:text-zinc-950 hover:bg-black/10 p-1.5 rounded-full transition-all cursor-pointer"
              title="بستن راهنما"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 pl-6">
              <Chrome className="w-8 h-8 animate-pulse text-zinc-950 shrink-0" />
              <div className="text-right">
                <p className="text-sm font-black text-zinc-950">⚠️ راهنمای طلایی نصب وب‌اپلیکیشن (PWA) روی گوشی:</p>
                <p className="text-[11px] text-zinc-900 font-bold mt-1 leading-relaxed">
                  شما در حال حاضر داخل محیط پیش‌نمایش ایمن هوش مصنوعی (IFrame) هستید. در این حالت امکان نصب وجود ندارد و کلیک معمولی روی لینک‌ها به دلیل مسائل امنیتی مرورگر با خطای <span className="bg-black/15 px-1 rounded">Redirect Notice</span> یا <span className="bg-black/15 px-1 rounded">404</span> مواجه می‌شود.
                  <br />
                  <span className="text-zinc-950 font-black">راه حل فوق‌العاده آسان:</span>
                  <br />
                  ۱. روی دکمه طلایی روبرو کلیک کنید تا سایت مستقل باز شود، یا آدرس را با دکمه کپی کرده و در تب جدید مرورگر خود (Chrome یا Safari) باز کنید.
                  <br />
                  ۲. سپس در مرورگر روی <span className="font-black">سه نقطه (یا دکمه Share در آیفون)</span> زده و گزینه <span className="font-black">«افزودن به صفحه اصلی» (Add to Home Screen)</span> را انتخاب کنید.
                </p>
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] text-zinc-800 bg-black/10 px-2 py-0.5 rounded font-mono select-all font-bold">
                    {typeof window !== "undefined" ? window.location.origin : ""}
                  </span>
                  <button
                    onClick={() => {
                      if (typeof window !== "undefined") {
                        navigator.clipboard.writeText(window.location.origin);
                        showToast("آدرس مستقیم با موفقیت کپی شد. آن را در مرورگر خود پیست کنید!");
                      }
                    }}
                    className="px-2 py-1 bg-black/20 hover:bg-black/30 rounded text-[9px] font-black transition-all cursor-pointer border border-black/10"
                  >
                    کپی کردن آدرس
                  </button>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 shrink-0 w-full md:w-auto">
              <button
                onClick={() => {
                  if (typeof window !== "undefined") {
                    const win = window.open(window.location.origin, "_blank");
                    if (!win) {
                      showToast("پاپ‌آپ توسط مرورگر مسدود شد! لطفاً آدرس را کپی کرده یا از دکمه بالای صفحه استفاده کنید.");
                    }
                  }
                }}
                className="px-5 py-3 bg-black hover:bg-zinc-900 text-amber-400 active:scale-[0.98] transition-all rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-lg cursor-pointer border border-zinc-800 w-full sm:w-auto text-center"
              >
                <span>باز کردن مستقیم تب جدید</span>
                <ExternalLink className="w-4 h-4 text-amber-400" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* HEADER SECTION */}
      <header className="relative max-w-6xl mx-auto pt-8 pb-4 flex flex-col md:flex-row items-center justify-between gap-6 border-b border-amber-500/10 z-10">
        
        {/* Logo and Brand */}
        <div className="flex items-center gap-4">
          <div className="relative w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border border-amber-500/30 shadow-lg shadow-amber-500/10 bg-[#0c0c0c] flex-shrink-0">
            <img 
              src={logoUrl} 
              alt="لوگو املاک میرکمبر" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="text-right">
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight gold-gradient-text flex items-center gap-2">
              املاک میرکمبر
            </h1>
            <p className="text-xs md:text-sm text-gray-400 mt-1">
              مدیریت هوشمند فایل‌های املاک • لوکس، مدرن و کارآمد
            </p>
          </div>
        </div>

        {/* Backups & Search Control panel */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          {/* Export button */}
          <button
            onClick={exportBackup}
            id="btn_export"
            className="flex items-center gap-2 px-3 py-2 text-xs md:text-sm font-medium rounded-lg bg-zinc-900 border border-amber-500/20 text-amber-200/80 hover:bg-zinc-800 hover:text-amber-200 transition-all cursor-pointer shadow-sm"
            title="خروجی گرفتن از فایل‌ها (پشتیبان)"
          >
            <Download className="w-4 h-4" />
            <span>صدور پشتیبان</span>
          </button>

          {/* Import button container */}
          <label
            htmlFor="import_file"
            id="label_import"
            className="flex items-center gap-2 px-3 py-2 text-xs md:text-sm font-medium rounded-lg bg-zinc-900 border border-amber-500/20 text-amber-200/80 hover:bg-zinc-800 hover:text-amber-200 transition-all cursor-pointer shadow-sm"
            title="وارد کردن فایل‌ها از فایل پشتیبان"
          >
            <Upload className="w-4 h-4" />
            <span>وارد کردن پشتیبان</span>
            <input 
              type="file" 
              id="import_file" 
              accept=".json" 
              onChange={handleImportBackup} 
              className="hidden" 
            />
          </label>
        </div>
      </header>

      {/* TOAST NOTIFICATION CONTAINER */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            id="toast_notification"
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-50 glass-panel border border-amber-500/40 text-amber-100 px-6 py-3 rounded-xl flex items-center gap-3 shadow-lg shadow-amber-500/5 font-medium text-sm text-center"
          >
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="relative max-w-6xl mx-auto mt-8 z-10">
        
        {/* TABS NAVIGATION */}
        <nav className="grid grid-cols-2 lg:grid-cols-4 gap-2 mb-6 bg-[#090909]/60 p-1.5 rounded-2xl border border-amber-500/10 backdrop-blur-sm">
          {tabList.map((tab) => {
            const IconComponent = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setExpandedFileId(null); // Clear expansion on tab change
                }}
                className={`flex items-center justify-center gap-3 px-4 py-3.5 rounded-xl font-medium text-sm md:text-base transition-all duration-300 relative overflow-hidden cursor-pointer ${
                  isActive
                    ? "text-amber-100 font-bold bg-amber-500/10 border border-amber-500/30 shadow-md shadow-amber-500/5"
                    : "text-gray-400 hover:text-gray-200 hover:bg-zinc-900/50"
                }`}
              >
                <IconComponent className={`w-4 h-4 md:w-5 md:h-5 ${isActive ? "text-amber-400" : "text-gray-400"}`} />
                <span>{tab.label}</span>
                {isActive && (
                  <motion.div 
                    layoutId="activeTabUnderline" 
                    className="absolute bottom-0 inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-amber-400 to-transparent" 
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* SEARCH AND ADD BUTTON BAR */}
        <section className="flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center mb-8">
          
          {/* Search bar */}
          <div className="relative flex-1 max-w-lg">
            <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-amber-400/60">
              <Search className="w-5 h-5" />
            </span>
            <input
              type="text"
              id="search_input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو در مشخصات و توضیحات این بخش..."
              className="w-full pl-4 pr-10 py-3 rounded-xl bg-zinc-900/60 border border-amber-500/20 text-gray-200 placeholder-gray-500 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/30 text-sm transition-all shadow-inner backdrop-blur-sm text-right"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery("")}
                className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500 hover:text-amber-400 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Add file button */}
          <button
            onClick={() => setIsAddModalOpen(true)}
            id="btn_add_property"
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl gold-gradient-bg text-black font-bold text-sm md:text-base hover:shadow-lg hover:shadow-amber-500/20 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-5 h-5 stroke-[2.5]" />
            <span>افزودن فایل جدید</span>
          </button>
        </section>

        {/* LIST OF PROPERTY FILES */}
        <section id="property_list_section" className="space-y-4">
          <div className="flex items-center justify-between px-2 mb-2 text-xs md:text-sm text-gray-500">
            <span>تعداد فایل‌ها در این بخش: {filteredFiles.length} فایل</span>
            {searchQuery && <span>نتایج فیلتر شده جستجو</span>}
          </div>

          <AnimatePresence mode="popLayout">
            {filteredFiles.length > 0 ? (
              filteredFiles.map((file) => {
                const isExpanded = expandedFileId === file.id;
                return (
                  <motion.div
                    key={file.id}
                    layout
                    id={`file_card_${file.id}`}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.25 }}
                    onClick={() => setExpandedFileId(isExpanded ? null : file.id)}
                    className="glass-panel glass-panel-hover rounded-2xl overflow-hidden cursor-pointer p-4 md:p-5 flex flex-col md:flex-row items-stretch md:items-start justify-between gap-4 relative"
                  >
                    
                    {/* File Info Left/Right Layout */}
                    <div className="flex-1 text-right">
                      {/* Specifications Header */}
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 rounded-full bg-amber-400 mt-2.5 flex-shrink-0 animate-pulse" />
                        <h3 className="text-base md:text-lg font-semibold text-amber-100 hover:text-amber-300 leading-relaxed transition-colors">
                          {file.specifications}
                        </h3>
                      </div>

                      {/* Expanded Description Area */}
                      <AnimatePresence initial={false}>
                        {isExpanded && (
                          <motion.div
                            id={`desc_${file.id}`}
                            initial={{ height: 0, opacity: 0, marginTop: 0 }}
                            animate={{ height: "auto", opacity: 1, marginTop: 16 }}
                            exit={{ height: 0, opacity: 0, marginTop: 0 }}
                            transition={{ duration: 0.3, ease: "easeInOut" }}
                            className="overflow-hidden border-t border-amber-500/10 pt-4"
                            onClick={(e) => e.stopPropagation()} // Prevents closing when clicking inside description text
                          >
                            <div className="flex items-start gap-2 bg-[#080808]/80 p-4 rounded-xl border border-zinc-800">
                              <FileText className="w-5 h-5 text-amber-500 mt-1 shrink-0" />
                              <div>
                                <h4 className="text-xs font-bold text-amber-500/70 mb-1.5">توضیحات و یادداشت‌ها:</h4>
                                <p className="text-sm md:text-base text-gray-300 whitespace-pre-wrap leading-loose">
                                  {file.description}
                                </p>
                              </div>
                            </div>
                            <div className="text-[10px] text-gray-500 mt-3 mr-1 flex items-center gap-1.5">
                              <span>ثبت شده در: {new Date(file.createdAt).toLocaleDateString("fa-IR")}</span>
                              <span>•</span>
                              <span>ساعت {new Date(file.createdAt).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })}</span>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Action Panel: Chevron and Delete Button */}
                    <div className="flex md:flex-col items-center justify-between md:justify-start gap-4 md:self-stretch md:border-r md:border-amber-500/10 md:pr-4">
                      
                      {/* Chevron Toggle */}
                      <span className="text-amber-500/70 hover:text-amber-400 transition-colors p-1 md:block hidden">
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </span>

                      {/* Delete file button */}
                      <button
                        onClick={(e) => handleDeleteFile(file.id, e)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/20 text-red-400 hover:bg-red-500/10 hover:border-red-500/40 active:scale-95 transition-all cursor-pointer text-xs font-medium md:mt-auto"
                        title="حذف این فایل"
                        id={`btn_delete_${file.id}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>حذف فایل</span>
                      </button>

                      {/* Expand Text for Mobile */}
                      <span className="text-xs text-amber-400/80 md:hidden flex items-center gap-1">
                        {isExpanded ? "بستن توضیحات" : "مشاهده توضیحات"}
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </span>

                    </div>

                  </motion.div>
                );
              })
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="glass-panel rounded-2xl p-12 text-center border-dashed border-amber-500/20"
                id="empty_state_container"
              >
                <Building2 className="w-12 h-12 text-amber-500/40 mx-auto mb-4 stroke-[1.5]" />
                <h3 className="text-lg font-bold text-amber-100/80 mb-2">هیچ فایلی یافت نشد</h3>
                <p className="text-sm text-gray-500 max-w-md mx-auto leading-relaxed">
                  {searchQuery 
                    ? "هیچ فایلی با این عبارات جستجو پیدا نشد. لطفاً فیلتر را تغییر دهید یا دکمه ضربدر را بزنید." 
                    : "در حال حاضر فایلی در این دسته‌بندی تعریف نشده است. با زدن دکمه «افزودن فایل جدید» اولین فایل را ثبت کنید."}
                </p>
                {!searchQuery && (
                  <button
                    onClick={() => setIsAddModalOpen(true)}
                    className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-bold transition-all border border-amber-500/20 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>افزودن اولین فایل</span>
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </section>

      </main>

      {/* FOOTER */}
      <footer className="relative max-w-6xl mx-auto mt-16 text-center text-xs text-gray-500 border-t border-zinc-900 pt-8 z-10">
        <p>© {new Date().toLocaleDateString("fa-IR", { year: "numeric" })} املاک میرکمبر. تمامی حقوق محفوظ است.</p>
        <p className="mt-1 text-[10px] text-gray-600">طراحی شده با تم مدرن شیشه‌ای مشکی-طلایی</p>
      </footer>

      {/* MODAL: ADD NEW FILE (PERSISTENT GLASS DESIGN) */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div id="add_file_modal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Modal Backdrop overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddModalOpen(false)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ scale: 0.95, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="relative w-full max-w-2xl bg-zinc-950 border border-amber-500/30 rounded-3xl overflow-hidden shadow-2xl shadow-amber-500/10 p-6 md:p-8 z-10 text-right flex flex-col max-h-[90vh]"
            >
              
              {/* Header */}
              <div className="flex items-center justify-between border-b border-amber-500/10 pb-4 mb-5">
                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-zinc-800 text-gray-400 hover:text-amber-400 transition-all cursor-pointer"
                  title="بستن پنجره"
                >
                  <X className="w-5 h-5" />
                </button>
                <div>
                  <h2 className="text-xl font-extrabold text-amber-200">افزودن فایل جدید</h2>
                  <p className="text-xs text-gray-400 mt-1">در دسته‌بندی: {tabList.find(t => t.id === activeTab)?.label}</p>
                </div>
              </div>

              {/* Form Content container (scrollable) */}
              <form onSubmit={handleSaveFile} className="space-y-5 flex-1 overflow-y-auto pr-1">
                
                {/* TEMPLATE QUICK HELPER (UX CRAFTSMANSHIP) */}
                <div className="bg-amber-500/[0.03] border border-amber-500/10 rounded-2xl p-4">
                  <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold mb-3">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>راهنمای ساخت سریع مشخصات (اختیاری)</span>
                  </div>
                  <p className="text-[11px] text-gray-400 mb-4 leading-relaxed">
                    با وارد کردن اطلاعات در این کادرها، متن مشخصات فایل شما به طور خودکار ساخته می‌شود. همچنین می‌توانید خودتان مستقیماً در کادر مشخصات تایپ کنید.
                  </p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1">متراژ (متر مربع)</label>
                      <input 
                        type="text" 
                        value={tempMetrage} 
                        onChange={(e) => setTempMetrage(e.target.value)}
                        placeholder="مثال: ۱۲۰"
                        className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-gray-300 focus:outline-none focus:border-amber-500/50 text-right"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1">تعداد اتاق</label>
                      <input 
                        type="text" 
                        value={tempRooms} 
                        onChange={(e) => setTempRooms(e.target.value)}
                        placeholder="مثال: ۲"
                        className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-gray-300 focus:outline-none focus:border-amber-500/50 text-right"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1">محدوده / آدرس</label>
                      <input 
                        type="text" 
                        value={tempLocation} 
                        onChange={(e) => setTempLocation(e.target.value)}
                        placeholder="مثال: پاسداران"
                        className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-gray-300 focus:outline-none focus:border-amber-500/50 text-right"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1">قیمت (تومان)</label>
                      <input 
                        type="text" 
                        value={tempPrice} 
                        onChange={(e) => setTempPrice(e.target.value)}
                        placeholder="مثال: ۱۲ میلیارد"
                        className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-gray-300 focus:outline-none focus:border-amber-500/50 text-right"
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={applyTemplate}
                    className="w-full py-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-xs font-semibold rounded-lg border border-amber-500/20 transition-all cursor-pointer"
                  >
                    تنظیم در کادر مشخصات اصلی ↓
                  </button>
                </div>

                {/* MAIN FIELD 1: specifications */}
                <div>
                  <label htmlFor="specifications_field" className="block text-sm font-semibold text-amber-200 mb-1.5">
                    مشخصات فایل <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="specifications_field"
                    value={specifications}
                    onChange={(e) => setSpecifications(e.target.value)}
                    rows={2}
                    placeholder="مشخصات کلیدی و خط اول فایل را اینجا بنویسید (مانند: آپارتمان ۱۲۰ متری، تک‌واحدی، ۲ خوابه، پاسداران)"
                    required
                    className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-gray-200 focus:outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/20 text-sm leading-relaxed transition-all text-right"
                  />
                  <p className="text-[11px] text-gray-500 mt-1">این متن در لیست اصلی بلافاصله برای مشتریان یا مشاورین نشان داده می‌شود.</p>
                </div>

                {/* MAIN FIELD 2: description */}
                <div>
                  <label htmlFor="description_field" className="block text-sm font-semibold text-amber-200 mb-1.5">
                    توضیحات و جزئیات تکمیلی <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="description_field"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={4}
                    placeholder="سایر مشخصات مانند نورگیر، بازسازی، نوع کابینت، شرایط پرداخت، وضعیت سند، تخفیف، شماره تماس مالک یا یادداشت‌های مشاور..."
                    required
                    className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-gray-200 focus:outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/20 text-sm leading-relaxed transition-all text-right"
                  />
                  <p className="text-[11px] text-gray-500 mt-1">این توضیحات تا زمان کلیک کاربر بر روی فایل به صورت کشویی مخفی می‌ماند.</p>
                </div>

                {/* Footer Buttons */}
                <div className="flex items-center justify-start gap-3 border-t border-zinc-900 pt-5 mt-6">
                  <button
                    type="submit"
                    className="px-6 py-3 rounded-xl gold-gradient-bg text-black font-extrabold text-sm md:text-base hover:shadow-lg hover:shadow-amber-500/20 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-5 h-5 stroke-[2.5]" />
                    <span>ذخیره فایل</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-5 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-gray-300 text-sm font-medium transition-all cursor-pointer border border-zinc-800"
                  >
                    انصراف
                  </button>
                </div>

              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: MOBILE INSTALLATION (PREMIUM CLASSY DESIGN) */}
      <AnimatePresence>
        {isMobileInstallModalOpen && (
          <div id="mobile_install_modal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Modal Backdrop overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileInstallModalOpen(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ scale: 0.95, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="relative w-full max-w-xl bg-zinc-950 border border-amber-500/30 rounded-3xl overflow-hidden shadow-2xl shadow-amber-500/10 p-6 md:p-8 z-10 text-right flex flex-col max-h-[90vh]"
            >
              
              {/* Header */}
              <div className="flex items-center justify-between border-b border-amber-500/10 pb-4 mb-5">
                <button
                  onClick={() => setIsMobileInstallModalOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-zinc-800 text-gray-400 hover:text-amber-400 transition-all cursor-pointer"
                  title="بستن پنجره"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="flex items-center gap-3">
                  <Smartphone className="w-6 h-6 text-amber-400 shrink-0" />
                  <div>
                    <h2 className="text-xl font-extrabold text-amber-200">نصب نرم‌افزار موبایل</h2>
                    <p className="text-xs text-gray-400 mt-1">املاک میرکمبر روی تلفن همراه شما</p>
                  </div>
                </div>
              </div>

              {/* Modal Body Container */}
              <div className="space-y-6 flex-1 overflow-y-auto pr-1 relative">
                
                {/* GLOWING DOWNLOAD PROGRESS OVERLAY */}
                {isDownloading && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 bg-black/95 backdrop-blur-md z-30 flex flex-col items-center justify-center p-6 text-center"
                  >
                    <div className="relative w-32 h-32 mb-6 flex items-center justify-center">
                      {/* Outer spinning gold ring */}
                      <div className="absolute inset-0 rounded-full border-4 border-amber-500/10 border-t-amber-500 animate-spin" />
                      {/* Inner gold glow */}
                      <div className="absolute inset-2 bg-amber-500/5 rounded-full blur-md" />
                      {/* Percentage display */}
                      <span className="text-3xl font-extrabold text-amber-300 font-mono">{downloadProgress}%</span>
                    </div>

                    <h3 className="text-lg font-bold text-amber-200 mb-2 animate-pulse">در حال ساخت فایل نصب اختصاصی</h3>
                    <p className="text-sm text-gray-300 max-w-sm leading-loose h-12">
                      {downloadStep}
                    </p>

                    {/* Progress Bar background */}
                    <div className="w-full max-w-md bg-zinc-900 rounded-full h-2 overflow-hidden mt-6 border border-zinc-800">
                      <div 
                        className="gold-gradient-bg h-full rounded-full transition-all duration-300"
                        style={{ width: `${downloadProgress}%` }}
                      />
                    </div>
                  </motion.div>
                )}

                {/* DIRECT DOWNLOAD BUTTONS SECTION (TOP PRIORITY) */}
                <div className="space-y-4">
                  <div className="text-xs text-amber-400 font-bold mb-1">روش هوشمند و استاندارد (وب‌اپلیکیشن پیشرو PWA):</div>
                  
                  <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-4 space-y-3">
                    <p className="text-xs text-gray-300 leading-relaxed">
                      این سامانه مجهز به فناوری <strong className="text-amber-300">PWA (وب‌اپلیکیشن پیشرو)</strong> و کنترل‌کننده فعال سرویس (Service Worker) است. دقیقاً مشابه برنامه‌های معروفی چون <strong className="text-amber-200">اسنپ و دیوار</strong>، با اضافه کردن آن به صفحه اصلی گوشی، همانند یک نرم‌افزار بومی با آیکون طلاکوب اختصاصی، بدون نوار بالای مرورگر و کاملاً تمام‌صفحه اجرا خواهد شد.
                    </p>
                    
                    {installDeviceType === "android" ? (
                      <div className="text-xs text-zinc-400 leading-relaxed bg-black/40 p-3 rounded-lg border border-zinc-900">
                        <span className="text-amber-400 font-bold">💡 راهنمای نصب سریع اندروید:</span> کافیست روی دکمه سه نقطه مرورگر کروم <span className="text-amber-300 font-bold">(⋮)</span> در بالا کلیک کرده و گزینه <strong className="text-amber-200">"Add to Home screen"</strong> یا <strong className="text-amber-200">"Install App"</strong> را بزنید.
                      </div>
                    ) : (
                      <div className="text-xs text-zinc-400 leading-relaxed bg-black/40 p-3 rounded-lg border border-zinc-900">
                        <span className="text-amber-400 font-bold">💡 راهنمای نصب سریع آیفون (Safari):</span> روی دکمه اشتراک‌گذاری <strong className="text-amber-200">Share</strong> (مربع با فلش رو به بالا) کلیک کرده و گزینه <strong className="text-amber-200">"Add to Home Screen"</strong> را بزنید.
                      </div>
                    )}
                  </div>

                  <div className="border-t border-zinc-900 pt-4 space-y-3">
                    <div className="text-xs text-amber-400 font-bold">راهنمای خروجی گرفتن فایل نصب مستقیم APK (برای توسعه‌دهندگان):</div>
                    <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-4 text-right space-y-2.5">
                      <p className="text-[11px] text-gray-300 leading-relaxed">
                        توجه داشته باشید که کدهای این وب‌سایت کاملاً استاندارد و مبتنی بر <strong className="text-amber-300">React + Vite + TypeScript</strong> طراحی شده‌اند. از آنجایی که سرورهای ابری مرورگر فاقد سیستم‌عامل اندروید و ابزارهای کامپایلر سنگین جاوا (Android SDK & JDK) هستند، امکان خروجی مستقیم فایل باینری <code className="text-amber-400">.apk</code> به صورت آنلاین وجود ندارد.
                      </p>
                      <p className="text-[11px] text-gray-400 leading-relaxed">
                        برای تبدیل این کدهای کامپایل شده به یک فایل نصب بومی اندروید (APK)، کافیست با استفاده از ابزار قدرتمند <strong className="text-gray-200">Capacitor</strong> روی سیستم خود این ۳ دستور ساده را اجرا کنید:
                      </p>
                      
                      <div className="bg-[#040404] p-3 rounded-lg border border-zinc-800 text-left font-mono text-[10px] text-emerald-400/90 whitespace-pre overflow-x-auto select-all leading-normal">
{`# 1. نصب ابزارهای کاپاسیتور در پروژه
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. راه‌اندازی کاپاسیتور و افزودن پلتفرم اندروید
npx cap init "Mirkambar Estate" "com.mirkambar.app" --web-dir=dist
npx cap add android

# 3. همگام‌سازی و ساخت نهایی فایل APK در اندروید استودیو
npm run build
npx cap sync
npx cap open android`}
                      </div>

                      <p className="text-[10px] text-amber-400/70">
                        با اجرای دستور بالا، اندروید استودیو باز شده و می‌توانید فایل APK نهایی، کامپایل شده، و امضا شده را با بالاترین حجم و سرعت تولید کنید.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Intro Card */}
                <div className="bg-amber-500/[0.02] border border-amber-500/15 rounded-2xl p-4 flex gap-3 items-start">
                  <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <p className="text-xs md:text-sm text-gray-300 leading-relaxed">
                    با نصب وب‌اپلیکیشن اختصاصی، سامانه املاک میرکمبر همانند یک نرم‌افزار بومی روی دسکتاپ گوشی شما قرار می‌گیرد. این نسخه همیشه به صورت آنی هماهنگ شده و هیچ فضایی از حافظه گوشی شما اشغال نمی‌کند.
                  </p>
                </div>

                {/* DEVICE CHOSEN TABS */}
                <div className="flex bg-[#090909]/80 p-1 rounded-xl border border-zinc-800">
                  <button
                    type="button"
                    onClick={() => setInstallDeviceType("android")}
                    className={`flex-1 py-2.5 rounded-lg font-bold text-xs md:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      installDeviceType === "android"
                        ? "bg-amber-500/10 text-amber-200 border border-amber-500/25"
                        : "text-gray-400 hover:text-gray-200"
                    }`}
                  >
                    <Smartphone className="w-4 h-4 text-green-500" />
                    <span>گوشی‌های اندروید (Android)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setInstallDeviceType("ios")}
                    className={`flex-1 py-2.5 rounded-lg font-bold text-xs md:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      installDeviceType === "ios"
                        ? "bg-amber-500/10 text-amber-200 border border-amber-500/25"
                        : "text-gray-400 hover:text-gray-200"
                    }`}
                  >
                    <Apple className="w-4 h-4 text-gray-100" />
                    <span>گوشی‌های آیفون (iOS)</span>
                  </button>
                </div>

                {/* STEPS LISTS */}
                {installDeviceType === "android" ? (
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-amber-300/90 flex items-center gap-1.5">
                      <Chrome className="w-4 h-4 text-amber-400" />
                      <span>راهنمای نصب سریع در مرورگر کروم (Chrome):</span>
                    </h3>

                    <div className="space-y-3 mr-1 text-xs md:text-sm text-gray-300">
                      <div className="flex items-start gap-3 bg-zinc-900/40 p-3 rounded-xl border border-zinc-900">
                        <span className="w-6 h-6 rounded-lg bg-amber-500/15 border border-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">۱</span>
                        <p className="leading-relaxed">
                          در بالای مرورگر کروم، روی دکمه سه نقطه <span className="text-amber-400 font-bold">(⋮)</span> بزنید.
                        </p>
                      </div>

                      <div className="flex items-start gap-3 bg-zinc-900/40 p-3 rounded-xl border border-zinc-900">
                        <span className="w-6 h-6 rounded-lg bg-amber-500/15 border border-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">۲</span>
                        <p className="leading-relaxed">
                          گزینه <span className="text-amber-400 font-bold">"Add to Home screen"</span> یا <span className="text-amber-400 font-bold">"نصب برنامه (Install App)"</span> را انتخاب کنید.
                        </p>
                      </div>

                      <div className="flex items-start gap-3 bg-zinc-900/40 p-3 rounded-xl border border-zinc-900">
                        <span className="w-6 h-6 rounded-lg bg-amber-500/15 border border-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">۳</span>
                        <p className="leading-relaxed">
                          تایید نهایی را بزنید تا برنامه با آیکون طلاکوب اختصاصی <span className="text-amber-400">املاک میرکمبر</span> در لیست برنامه‌های گوشی قرار گیرد.
                        </p>
                      </div>
                    </div>

                    {/* Alternative Shortcut Downloader */}
                    <div className="border-t border-zinc-900 pt-4 mt-2">
                      <p className="text-[11px] text-gray-400 mb-3 leading-relaxed">
                        همچنین می‌توانید فایل کلید میانبر لوکس برنامه را دانلود کنید تا با لمس آن، مستقیماً وارد برنامه شوید:
                      </p>
                      <button
                        type="button"
                        onClick={downloadMobileShortcut}
                        className="w-full py-3 rounded-xl bg-zinc-900 border border-amber-500/20 text-amber-200/80 hover:bg-zinc-800 hover:text-amber-200 transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md"
                      >
                        <DownloadCloud className="w-4 h-4 shrink-0" />
                        <span>دانلود مستقیم فایل میانبر موبایل و ویندوز (شبیه‌ساز URL)</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-amber-300/90 flex items-center gap-1.5">
                      <Apple className="w-4 h-4 text-gray-200" />
                      <span>راهنمای نصب سریع در مرورگر سافاری (Safari):</span>
                    </h3>

                    <div className="space-y-3 mr-1 text-xs md:text-sm text-gray-300">
                      <div className="flex items-start gap-3 bg-zinc-900/40 p-3 rounded-xl border border-zinc-900">
                        <span className="w-6 h-6 rounded-lg bg-amber-500/15 border border-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">۱</span>
                        <p className="leading-relaxed">
                          در مرورگر سافاری آیفون، روی دکمه اشتراک‌گذاری <span className="text-amber-400 font-bold">Share</span> (آیکون مربع با فلش رو به بالا) در منوی پایین بزنید.
                        </p>
                      </div>

                      <div className="flex items-start gap-3 bg-zinc-900/40 p-3 rounded-xl border border-zinc-900">
                        <span className="w-6 h-6 rounded-lg bg-amber-500/15 border border-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">۲</span>
                        <p className="leading-relaxed">
                          منو را به پایین اسکرول کنید و روی گزینه <span className="text-amber-400 font-bold">"Add to Home Screen"</span> یا <span className="text-amber-400 font-bold">"افزودن به صفحه اصلی"</span> کلیک کنید.
                        </p>
                      </div>

                      <div className="flex items-start gap-3 bg-zinc-900/40 p-3 rounded-xl border border-zinc-900">
                        <span className="w-6 h-6 rounded-lg bg-amber-500/15 border border-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">۳</span>
                        <p className="leading-relaxed">
                          در نهایت در بالای صفحه سمت راست دکمه <span className="text-amber-400 font-bold">Add</span> را لمس کنید تا آیکون مجلل برنامه روی گوشی شما فعال شود.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Advantages Info footer */}
                <div className="bg-[#0c0c0c] border border-zinc-800 rounded-xl p-3 text-[11px] text-gray-400 flex gap-2 items-center leading-relaxed">
                  <Info className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>بروزرسانی داده‌ها در اپلیکیشن همواره اتوماتیک بوده و نیازی به دانلود مجدد فایل‌های بروزرسانی نخواهید داشت.</span>
                </div>

              </div>

              {/* Close Button Footer */}
              <div className="flex items-center justify-end border-t border-zinc-900 pt-4 mt-5">
                <button
                  type="button"
                  onClick={() => setIsMobileInstallModalOpen(false)}
                  className="px-6 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-gray-300 text-xs font-bold transition-all cursor-pointer border border-zinc-800"
                >
                  فهمیدم، متشکرم
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: CUSTOM DELETE CONFIRMATION (PREMIUM GLASSY DESIGN) */}
      <AnimatePresence>
        {fileIdToDelete && (
          <div id="delete_confirm_modal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Modal Backdrop overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setFileIdToDelete(null)}
              className="absolute inset-0 bg-black/85 backdrop-blur-sm"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ scale: 0.95, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              transition={{ type: "spring", duration: 0.3 }}
              className="relative w-full max-w-md bg-zinc-950 border border-red-500/30 rounded-2xl overflow-hidden shadow-2xl shadow-red-500/5 p-6 z-10 text-right flex flex-col"
            >
              
              {/* Header / Icon */}
              <div className="flex items-center gap-3 border-b border-zinc-900 pb-4 mb-4">
                <div className="w-10 h-10 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 shrink-0">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-red-200">تایید حذف فایل ملکی</h3>
                  <p className="text-[11px] text-gray-400 mt-0.5">حذف همیشگی داده‌ها از حافظه مرورگر</p>
                </div>
              </div>

              {/* Body */}
              <div className="space-y-3 py-2 text-xs md:text-sm text-gray-300 leading-loose">
                <p>آیا از حذف این فایل املاک میرکمبر اطمینان کامل دارید؟</p>
                <div className="bg-red-500/[0.02] border border-red-500/10 p-3 rounded-xl text-[11px] text-red-400/80">
                  ⚠️ هشدار: این عملیات غیرقابل بازگشت است و مشخصات این فایل برای همیشه پاک خواهد شد.
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 items-center justify-end border-t border-zinc-900 pt-4 mt-4">
                <button
                  type="button"
                  onClick={() => setFileIdToDelete(null)}
                  className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-gray-300 text-xs font-bold transition-all cursor-pointer border border-zinc-800"
                >
                  خیر، انصراف
                </button>
                <button
                  type="button"
                  onClick={confirmDeleteFile}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white text-xs font-extrabold transition-all cursor-pointer shadow-lg shadow-red-500/10"
                >
                  بله، حذف شود
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
