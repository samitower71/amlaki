// Minimal service worker to satisfy PWA installability requirements
// without caching any resources (to prevent white screen/stale file bugs)

self.addEventListener('install', (e) => {
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => caches.delete(key))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  // Only handle HTTP and HTTPS requests to avoid protocol errors in browser extensions (like chrome-extension://)
  if (e.request.url.startsWith('http') || e.request.url.startsWith('https')) {
    e.respondWith(fetch(e.request));
  }
});
